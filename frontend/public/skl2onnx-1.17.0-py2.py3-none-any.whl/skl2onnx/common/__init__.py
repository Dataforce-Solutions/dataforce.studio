# SPDX-License-Identifier: Apache-2.0


# skl2onnx common code has been refactored into onnxconverter-common.

from .exceptions import MissingShapeCalculator, MissingConverter  # noqa
