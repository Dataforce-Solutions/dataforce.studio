# SPDX-License-Identifier: Apache-2.0


from .onnx_operator import OnnxOperator  # noqa
