# SPDX-License-Identifier: Apache-2.0

"""
Shortcuts to *tutorial*.
"""

from .benchmark import measure_time  # noqa
