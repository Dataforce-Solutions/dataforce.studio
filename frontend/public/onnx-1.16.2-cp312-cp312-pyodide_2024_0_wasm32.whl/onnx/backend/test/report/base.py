# Copyright (c) ONNX Project Contributors

# SPDX-License-Identifier: Apache-2.0


class ReporterBase:
    pass
