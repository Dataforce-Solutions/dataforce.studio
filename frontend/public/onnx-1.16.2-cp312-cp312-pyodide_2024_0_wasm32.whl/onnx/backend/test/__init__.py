# Copyright (c) ONNX Project Contributors
#
# SPDX-License-Identifier: Apache-2.0

__all__ = ["BackendTest"]
# for backward compatibility
from onnx.backend.test.runner import Runner as BackendTest
