__version__ = "0.8.0"
__author__ = "Oleh Kostromin, Iryna Kondrashchenko"

from falcon.main import initialize, AutoML
from falcon.utils import disable_warnings

disable_warnings()
