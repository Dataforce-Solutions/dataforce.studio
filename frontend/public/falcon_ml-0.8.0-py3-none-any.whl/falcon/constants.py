TABULAR_CLASSIFICATION_TASK = 'tabular_classification'
TABULAR_REGRESSION_TASK = 'tabular_regression'