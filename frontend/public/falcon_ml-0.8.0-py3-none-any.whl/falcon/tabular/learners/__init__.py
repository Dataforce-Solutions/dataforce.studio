from falcon.tabular.learners.super_learner import SuperLearner
from falcon.tabular.learners.optuna_learner import OptunaLearner
from falcon.tabular.learners.plain_learner import PlainLearner