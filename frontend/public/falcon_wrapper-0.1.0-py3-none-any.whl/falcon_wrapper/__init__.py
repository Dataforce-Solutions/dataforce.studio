from falcon_wrapper.tabular import tabular_deallocate, tabular_predict, tabular_train


def ping():
    return "it works!"
